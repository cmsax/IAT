## scf for python-3.6

Notice that `template.yaml` file contains environment variables, thus it should not be uploaded to this repository.

You can rename `demo-template.yaml` to `template.yaml`.
